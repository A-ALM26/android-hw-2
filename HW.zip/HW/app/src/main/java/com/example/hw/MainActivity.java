package com.example.hw;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       final EditText x = findViewById(R.id.editTextTextPersonName);
        final EditText y = findViewById(R.id.editTextTextPersonName2);
 final EditText s = findViewById(R.id.editTextTextPersonName3);
   final EditText z = findViewById(R.id.editTextTextPersonName4);
 Button CAL = findViewById(R.id.button);
CAL.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        double A = Double.parseDouble(x.getText().toString());
   double B = Double.parseDouble(y.getText().toString());
        double C = Double.parseDouble(s.getText().toString());
        double D = Double.parseDouble(z.getText().toString());
  double Number = A + B + C + D ;
        Toast.makeText(MainActivity.this, Number + "", Toast.LENGTH_SHORT).show();
    }
});
    }
}